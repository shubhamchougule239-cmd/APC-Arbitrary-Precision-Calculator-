#ifndef APC_H
#define APC_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

// Structure for node
typedef struct Dlist
{
    int data;
    struct Dlist *next;
    struct Dlist *prev;
} node;

extern char op;

// Fuction Prototype
int convert(int count, char **argv, node **N1_head, node **N1_tail, node **N2_head, node **N2_tail);
int validation(int count, char *argv[]);
int compare(node *n1, node *n2);

void print(node *R_head);
void opration();

void creat(int data, node **head, node **tail);
void res_creat(int data, node **head, node **tail);
void dl_delete_first(node **head, node **tail);

void copy(node **res, node **temp, node **t1);
void delete(node **t);
void insert_tail(node **head, node **tail, int data);
void remove_leading_zeros(node **head, node **tail);
void check(node **N1_head, node **N1_tail, node **N2_head, node **N2_tail, node **R_head, node **R_tail);

void add(node **N1_head, node **N1_tail, node **N2_head, node **N2_tail, node **R_head, node **R_tail, int P);
void sub(node **N1_head, node **N1_tail, node **N2_head, node **N2_tail, node **R_head, node **R_tail, int P);
void dive(node **N1_head, node **N1_tail,node **N2_head, node **N2_tail,node **R_head, node **R_tail);
void mul(node **N1_head, node **N1_tail, node **N2_head, node **N2_tail, node **R_head, node **R_tail, int P);

#endif

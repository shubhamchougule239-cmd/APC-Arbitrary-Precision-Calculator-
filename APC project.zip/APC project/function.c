#include "prototype.h"

// Global Variable declartion
int len1, len2, flag = 0, big = 0;
char S_num1 = '+', op, S_num2 = '+';

// printing THe Link list
void print(node *R_head)
{
    printf("Result : ");
    if (flag)
    {
        printf("- ");
    }
   
    while (R_head != NULL)
    {

        printf("%d", (R_head)->data);
        R_head = (R_head)->next;
    }
    printf("\n");
    return;
}

// Delete the Temperory linked list nodes
void delete(node **t)
{
    while (*t != NULL)
    {
        node *fr = *t;
        *t = fr->next;
        free(fr);
    }
}

// Copy the element
void copy(node **res, node **temp, node **t1)
{
    while (*res != NULL)
    {
        creat((*res)->data, temp, t1);
        *res = (*res)->next;
    }
}

// Checking The opration
void opration()
{

    if (op == '+')
    {
        if (S_num1 == '+' && S_num2 == '+')
        {
            op = '+';
        }
        else if (S_num1 == '-' && S_num2 == '-')
        {
            op = '+';
            flag = 1;
        }
        else if (S_num1 == '+' && S_num2 == '-')
        {
            op = '-';
            if (big < 0)
            {
                flag = 1;
            }
        }
        else
        {
            op = '-';
            if (big > 0)
            {
                flag = 1;
            }
        }
    }
    else if (op == '-')
    {
        if (S_num1 == '+' && S_num2 == '+')
        {
            op = '-';
            if (big < 0)
            {
                flag = 1;
            }
        }
        else if (S_num1 == '+' && S_num2 == '-')
        {
            op = '+';
        }
        else if (S_num1 == '-' && S_num2 == '+')
        {
            op = '+';
            flag = 1;
        }
        else
        {
            op = '-';
            if (big > 0)
            {
                flag = 1;
            }
        }
    }
    else
    {
        if (S_num1 == '-' && S_num2 == '+')
        {
            flag = 1;
        }
        else if (S_num1 == '+' && S_num2 == '-')
        {
            flag = 1;
        }
    }
}

// Romove The frist Zeros
void remove_leading_zeros(node **head, node **tail)
{
    while (*head && (*head)->data == 0)
    {
        dl_delete_first(head, tail);
    }
}

// Validation 
int validation(int count, char *argv[])
{
    // Checking the CCount of argv
    if (count != 4)
    {
        printf("The argument is not enough for processing\n");
        return 0;
    }

    // Checking the frist index oply contain '+' ,'-'and only digit
    if ((argv[1][0] != '+' && argv[1][0] != '-' && (argv[1][0] < '0' || argv[1][0] > '9')) ||
        (argv[3][0] != '+' && argv[3][0] != '-' && (argv[3][0] < '0' || argv[3][0] > '9')))
    {
        printf("Element is not Valid\n");
        return 0;
    }
    if (strlen(argv[2]) != 1)
    {
        printf("The operator is Invalid\n");
        return 0;
    }

    // Checking The oprator is valid or not
    if (*argv[2] != '+' && *argv[2] != '-' && *argv[2] != 'x' && *argv[2] != '/')
    {
        printf("The oprator Is Invalid\n");
        return 0;
    }

    // store the sign of oprand
    if (argv[1][0] == '-')
    {
        S_num1 = '-';
    }
    if (argv[3][0] == '-')
    {
        S_num2 = '-';
    }

    // Remove the Frist zeros and Sign
    while ((argv[1][0] == '0' && argv[1][1] != '\0') || (argv[1][0] == '-' || argv[1][0] == '-'))
    {
        for (int i = 0; i < strlen(argv[1]); i++)
        {
            argv[1][i] = argv[1][i + 1];
        }
    }
    len1 = strlen(argv[1]);

    while ((argv[3][0] == '0' && argv[3][1] != '\0') || (argv[3][0] == '-' || argv[3][0] == '-'))
    {
        for (int i = 0; i < strlen(argv[3]); i++)
        {
            argv[3][i] = argv[3][i + 1];
        }
    }
    len2 = strlen(argv[3]);
    // Checking The all input is only digit or not

    for (int i = 0; argv[1][i] != '\0'; i++)
    {
        if (!isdigit((unsigned char)argv[1][i]))
        {
            printf("The Operator 1 must have only digits\n");
            return 0;
        }
    }
    for (int i = 0; argv[3][i] != '\0'; i++)
    {
        if (!isdigit((unsigned char)argv[3][i]))
        {
            printf("The Operator 2 must have only digits\n");
            return 0;
        }
    }

    // check the which on is the bigger value
    big = strcmp(argv[1], argv[3]);

    printf("VAlidation Complete\n");
    return 1;
}

// create the Linked list
void creat(int data, node **head, node **tail)
{
    node *new = malloc(sizeof(node));
    new->data = data;
    new->next = NULL;
    new->prev = NULL;

    if (*head == NULL)
    {
        *head = new;
        *tail = new;
        return;
    }
    new->prev = *tail;
    (*tail)->next = new;
    *tail = new;
}

// Delete frist Node
void dl_delete_first(node **head, node **tail)
{
    if (*head == NULL)
    {
        return;
    }

    node *temp = *head;

    if (*head == *tail)
    {
        *head = NULL;
        *tail = NULL;
    }
    else
    {
        *head = (*head)->next;
        (*head)->prev = NULL;
    }

    free(temp);
    return;
}

// Result node created
void res_creat(int data, node **head, node **tail)
{
    node *new = malloc(sizeof(node));
    new->data = data;
    new->next = NULL;
    new->prev = NULL;

    if (*head == NULL)
    {
        *head = new;
        *tail = new;
        return;
    }

    new->next = *head;
    (*head)->prev = new;
    *head = new;
}

// Insert last node
void insert_tail(node **head, node **tail, int data)
{
    node *new = malloc(sizeof(node));

    if (new == NULL)
        return; 

    new->data = data;
    new->next = NULL;
    new->prev = NULL;

    
    if (*head == NULL)
    {
        *head = new;
        *tail = new;
    }
    else
    {
        new->prev = *tail;
        (*tail)->next = new;
        *tail = new;
    }
}

// Convert string into link list
int convert(int count, char **argv, node **N1_head, node **N1_tail, node **N2_head, node **N2_tail)

{
    int i = 0, j = 0;
    if (argv[1][0] == '-' || argv[1][0] == '+')
    {
        i = 1;
    }
    if (argv[3][0] == '-' || argv[3][0] == '+')
    {
        j = 1;
    }
    while (argv[1][i] != '\0')
    {
        char ch = argv[1][i];
        creat((ch - '0'), N1_head, N1_tail);
        i++;
    }
    while (argv[3][j] != '\0')
    {
        char ch = argv[3][j];
        creat((ch - '0'), N2_head, N2_tail);
        j++;
    }

    return 1;
}

// For The Addition
void add(node **N1_head, node **N1_tail, node **N2_head, node **N2_tail, node **R_head, node **R_tail, int P)
{
    int carry = 0;
    while (*N1_tail != NULL || *N2_tail != NULL)
    {

        int d1 = (*N1_tail != NULL) ? (*N1_tail)->data : 0;
        int d2 = (*N2_tail != NULL) ? (*N2_tail)->data : 0;

        int sum = d1 + d2 + carry;
        carry = (sum > 9) ? 1 : 0;

        res_creat(sum % 10, R_head, R_tail);

        if (*N1_tail)
            *N1_tail = (*N1_tail)->prev;
        if (*N2_tail)
            *N2_tail = (*N2_tail)->prev;
    }

    if (carry)
    {
        res_creat(1, R_head, R_tail);
    }
    if (P == 1)
    {
        print(*R_head);
    }
}

// For The substraction
void sub(node **N1_head, node **N1_tail, node **N2_head, node **N2_tail, node **R_head, node **R_tail, int P)
{
    int borrow = 0;

    while ((*N1_tail) != NULL || (*N2_tail) != NULL)
    {

        int d1 = 0, d2 = 0;

        if (*N1_tail != NULL)
        {
            d1 = (*N1_tail)->data;
        }

        if (*N2_tail != NULL)
        {
            d2 = (*N2_tail)->data;
        }

        d1 = d1 - borrow;

        if (d1 < d2)
        {
            d1 += 10;
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }

        int diff = d1 - d2;
        res_creat(diff, R_head, R_tail);

        if (*N1_tail != NULL)
        {
            *N1_tail = (*N1_tail)->prev;
        }

        if (*N2_tail != NULL)
        {
            *N2_tail = (*N2_tail)->prev;
        }
    }
    remove_leading_zeros(R_head,R_tail);
    if (P == 1)
    {
        print(*R_head);
    }
}

// Checking The number for subtraction
void check(node **N1_head, node **N1_tail, node **N2_head, node **N2_tail, node **R_head, node **R_tail)
{
    int ch = 0;
    // If length is same 
    if (len1 == len2)
    {
        node *t1 = *N1_head;
        node *t2 = *N2_head;

        while (t1 != NULL && t2 != NULL)
        {
            if (t1->data > t2->data)
            {
                ch = 1;
                break;
            }
            else if (t1->data < t2->data)
            {
                ch = -1;
                break;
            }
            t1 = t1->next;
            t2 = t2->next;
        }

        if (ch == 1)
            sub(N1_head, N1_tail, N2_head, N2_tail, R_head, R_tail, 1);
        else if (ch == -1)
        {
            sub(N2_head, N2_tail, N1_head, N1_tail, R_head, R_tail, 1);
            flag = 1;
        }
        else
            res_creat(0, R_head, R_tail);
    }
    // if the frist link is big
    else if (len1 > len2)
        sub(N1_head, N1_tail, N2_head, N2_tail, R_head, R_tail, 1);
    else
    {
        sub(N2_head, N2_tail, N1_head, N1_tail, R_head, R_tail, 1);
        flag = 1;
    }
    // leading Zeros 
    remove_leading_zeros(R_head,R_tail);
   
}

// For the multiplication
void mul(node **N1_head, node **N1_tail, node **N2_head, node **N2_tail, node **R_head, node **R_tail, int P)
{
    node *T_ptr1 = *N1_tail;
    int count = 0;

    node *H_ptr1 = NULL, *H_tail1 = NULL; // result

    // initialize result = 0
    res_creat(0, &H_ptr1, &H_tail1);

    while (T_ptr1 != NULL)
    {
        node *T_ptr2 = *N2_tail;

        node *temp_h = NULL, *temp_t = NULL;
        int carry = 0;

        // shift zeros
        for (int i = 0; i < count; i++)
        {
            res_creat(0, &temp_h, &temp_t);
        }

        while (T_ptr2 != NULL)
        {
            int mul = T_ptr1->data * T_ptr2->data + carry;

            carry = mul / 10;
            res_creat(mul % 10, &temp_h, &temp_t);

            T_ptr2 = T_ptr2->prev;
        }

        if (carry > 0)
        {
            res_creat(carry, &temp_h, &temp_t);
        }

        // store addition result
        node *new_h = NULL, *new_t = NULL;

        add(&H_ptr1, &H_tail1, &temp_h, &temp_t, &new_h, &new_t, 0);

        // free old result and temp
        delete(&H_ptr1);
        delete(&temp_h);

        // update accumulator
        H_ptr1 = new_h;
        H_tail1 = new_t;

        T_ptr1 = T_ptr1->prev;
        count++;
    }

    *R_head = H_ptr1;
    *R_tail = H_tail1;

    if (P == 1)
    {
        print(*R_head);
    }
}

// Compaire for the division 
int compare(node *n1, node *n2)
{
    int len1 = 0, len2 = 0;

    node *t1 = n1;
    node *t2 = n2;

    while (t1)
    {
        len1++;
        t1 = t1->next;
    }

    while (t2)
    {
        len2++;
        t2 = t2->next;
    }

    if (len1 > len2)
        return 1;
    else if (len1 < len2)
        return -1;

    t1 = n1;
    t2 = n2;

    while (t1 && t2)
    {
        if (t1->data > t2->data)
            return 1;
        else if (t1->data < t2->data)
            return -1;

        t1 = t1->next;
        t2 = t2->next;
    }

    return 0;
}

// For the division
void dive(node **N1_head, node **N1_tail,node **N2_head, node **N2_tail,node **R_head, node **R_tail)
{
    node *ptr = *N1_head;

    node *curr_head = NULL;
    node *curr_tail = NULL;

    while (ptr != NULL)
    {
        // build current number
        insert_tail(&curr_head, &curr_tail, ptr->data);

        // remove leading zeros
        remove_leading_zeros(&curr_head, &curr_tail);

        int count = 0;

        // subtract until smaller
        while (compare(curr_head, *N2_head) >= 0)
        {
            node *tempH = NULL, *tempT = NULL;

            sub(&curr_head, &curr_tail,
                N2_head, N2_tail,
                &tempH, &tempT, 0);

            curr_head = tempH;
            curr_tail = tempT;

            remove_leading_zeros(&curr_head, &curr_tail);

            count++;
        }

        //store quotient digit
        insert_tail(R_head, R_tail, count);

        ptr = ptr->next;
    }

    // Final cleanup (remove leading zero in result)
    remove_leading_zeros(R_head, R_tail);
    print(*R_head);
}
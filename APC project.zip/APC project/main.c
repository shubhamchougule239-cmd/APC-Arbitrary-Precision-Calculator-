#include "prototype.h"

int main(int count, char **argv)
{
    // All linked list head and tail pointers are declared and initialization

    node *N1_head = NULL;
    node *N2_head = NULL;
    node *R_head = NULL;

    node *N1_tail = NULL;
    node *N2_tail = NULL;
    node *R_tail = NULL;

    // function call for validation
    if (!validation(count, argv))
    {
        printf("The calculation failed!\n");
        printf("Use Only '+','-','x','/'\n");
        return 0;
    }

    // Convert the string into linked list
    if (!convert(count, argv, &N1_head, &N1_tail, &N2_head, &N2_tail))
    {
        printf("The calculation failed!\n");
        return 0;
    }

    op = argv[2][0];
    // Function call for checking sign and operation
    opration();

    // Function calls as per the operation
    switch (op)
    {
    case '+':
        // Fuction call for Addition
        add(&N1_head, &N1_tail, &N2_head, &N2_tail, &R_head, &R_tail, 1);
        break;
    case '-':
        // Function call for Subtraction
        check(&N1_head, &N1_tail, &N2_head, &N2_tail, &R_head, &R_tail);
        break;
    case 'x':
        // Function call for Multiplication
        mul(&N1_head, &N1_tail, &N2_head, &N2_tail, &R_head, &R_tail, 1);
        break;
    case '/':
        // Function call for Division
        dive(&N1_head, &N1_tail, &N2_head, &N2_tail, &R_head, &R_tail);
        break;
    default:
        // For Invalid input
        printf("The Operator is Invalid!\n");
        break;
    }
    return 1;
}